@echo off
cd /d "%~dp0"
".venv\Scripts\python.exe" -m hinglish_cut prepare --config config.cpu.json
pause
