"""Local Hinglish script assembly and editable XML export."""
__version__ = '0.1.0'
