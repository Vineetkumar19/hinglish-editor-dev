from pathlib import Path
from fractions import Fraction
import hashlib
import wave
from .model import Media

SAMPLE_RATE=16000
EXTENSIONS={'.mp4','.mov','.mkv','.avi','.m4v','.webm','.mts','.m2ts'}


def fingerprint(path):
    """Whole-file digest prevents stale cache when footage is replaced in place."""
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while chunk:=f.read(4*1024*1024):
            h.update(chunk)
    return h.hexdigest()


def probe(path):
    import av
    path=Path(path).resolve()
    with av.open(str(path)) as container:
        videos=container.streams.video
        audios=container.streams.audio
        if not videos or not audios:
            raise ValueError(f'{path.name}: both video and embedded audio are required')
        v=videos[0]; a=audios[0]
        if len(audios)>1:
            raise ValueError(f'{path.name}: multiple audio streams; create a copy with the intended audio stream first')
        fps=v.average_rate
        if not fps or fps<=0:
            raise ValueError(f'{path.name}: unknown frame rate')
        nominal=round(float(fps))
        supported=[Fraction(x) for x in (24,25,30,48,50,60)]+[Fraction(x*1000,1001) for x in (24,30,60)]
        nearest=min(supported,key=lambda x:abs(float(x-fps)))
        if abs(float(nearest-fps))>.001:
            raise ValueError(f'{path.name}: unsupported frame rate {fps}')
        fps=nearest
        if v.sample_aspect_ratio not in (None,Fraction(1)):
            raise ValueError(f'{path.name}: non-square pixels must be conformed before import')
        if int(v.metadata.get('rotate','0'))%360:
            raise ValueError(f'{path.name}: bake camera rotation into a conformed copy first')
        times=[]
        for packet in container.demux(v):
            if packet.pts is not None:
                times.append(float(packet.pts*v.time_base))
        times.sort()
        if len(times)<2:
            raise ValueError(f'{path.name}: too few video frames')
        step=1/float(fps)
        tolerance=max(float(v.time_base)*1.1,step*.005)
        if any(abs((b-a)-step)>tolerance for a,b in zip(times,times[1:])):
            raise ValueError(f'{path.name}: variable frame rate or missing frames; conform to constant frame rate first')
        duration=len(times)/float(fps)
        return Media(hashlib.sha256(str(path).encode()).hexdigest()[:16],str(path),duration,str(fps),
                     v.width,v.height,a.codec_context.channels,a.codec_context.sample_rate,times[0])


def extract_audio(media, destination):
    """Decode to disk, preserving audio offset relative to first video frame."""
    import av
    import numpy as np
    destination=Path(destination)
    destination.parent.mkdir(parents=True,exist_ok=True)
    with av.open(media.path) as container, wave.open(str(destination),'wb') as out:
        stream=container.streams.audio[0]
        resampler=av.AudioResampler(format='s16',layout='mono',rate=SAMPLE_RATE)
        out.setparams((1,2,SAMPLE_RATE,0,'NONE','not compressed'))
        limit=round(media.duration*SAMPLE_RATE)
        written=0
        def write_frame(frame):
            nonlocal written
            data=frame.to_ndarray().reshape(-1).astype('<i2',copy=False)
            target=round((float(frame.pts*frame.time_base)-media.video_start)*SAMPLE_RATE) if frame.pts is not None else written
            if target>written:
                padding=min(target-written,limit-written)
                out.writeframesraw(bytes(max(0,padding)*2)); written+=padding
            overlap=max(0,written-target)
            data=data[overlap:overlap+max(0,limit-written)]
            out.writeframesraw(data.tobytes()); written+=len(data)
        for frame in container.decode(stream):
            for converted in resampler.resample(frame):
                write_frame(converted)
        for converted in resampler.resample(None):
            write_frame(converted)
        while written<limit:
            size=min(limit-written,SAMPLE_RATE*10)
            out.writeframesraw(bytes(size*2)); written+=size


def read_audio(path,start=0,end=None):
    import numpy as np
    with wave.open(str(path),'rb') as f:
        if f.getframerate()!=SAMPLE_RATE or f.getnchannels()!=1 or f.getsampwidth()!=2:
            raise ValueError('Expected 16 kHz mono PCM16 analysis audio')
        begin=min(f.getnframes(),max(0,round(start*SAMPLE_RATE)))
        stop=f.getnframes() if end is None else min(f.getnframes(),round(end*SAMPLE_RATE))
        f.setpos(begin)
        return np.frombuffer(f.readframes(max(0,stop-begin)),dtype='<i2').astype(np.float32)/32768.0


def assemble_audio(cuts,media,audio_paths,destination):
    """Reconstruct frame-quantized edits for the evaluator, with no time stretching."""
    with wave.open(str(destination),'wb') as out:
        out.setparams((1,2,SAMPLE_RATE,0,'NONE','not compressed'))
        for cut in cuts:
            m=media[cut.media_id]
            start=round(Fraction(cut.start_frame*SAMPLE_RATE)/m.rate)
            count=round(Fraction(cut.duration*SAMPLE_RATE)/m.rate)
            with wave.open(str(audio_paths[cut.media_id]),'rb') as source:
                if start+count>source.getnframes()+1:
                    raise ValueError('Cut exceeds decoded source audio')
                source.setpos(min(start,source.getnframes()))
                data=source.readframes(count)
                # At NTSC boundaries there can be one sample of rounding difference.
                out.writeframesraw(data+bytes(max(0,count*2-len(data))))
