"""Final Cut Pro 7 XML (xmeml v5), not modern Apple FCPXML."""
from pathlib import Path
from fractions import Fraction
import math
import xml.etree.ElementTree as ET


def add(parent,name,value=None,**attrs):
    e=ET.SubElement(parent,name,attrs)
    if value is not None:
        e.text=str(value)
    return e


def rate(parent,fps):
    value=Fraction(fps)
    r=add(parent,'rate')
    nominal=round(float(value))
    if value not in (Fraction(nominal),Fraction(nominal*1000,1001)):
        raise ValueError(f'Unsupported XML frame rate: {fps}')
    add(r,'timebase',nominal)
    add(r,'ntsc','TRUE' if value.denominator==1001 else 'FALSE')


def video_format(parent,m):
    rate(parent,m.fps)
    add(parent,'width',m.width)
    add(parent,'height',m.height)
    add(parent,'anamorphic','FALSE')
    add(parent,'pixelaspectratio','square')
    add(parent,'fielddominance','none')


def export_xml(path,cuts,media):
    if not cuts:
        raise ValueError('No matched cuts to export')
    used=[media[c.media_id] for c in cuts]
    if len({m.rate for m in used})!=1:
        raise ValueError('Mixed frame rates: conform source files to one constant frame rate first')
    for c in cuts:
        m=media[c.media_id]
        if c.start_frame<0 or c.end_frame<=c.start_frame or c.end_frame>math.floor(m.duration*float(m.rate)+1e-6):
            raise ValueError(f'Invalid source bounds: {c}')
    root=ET.Element('xmeml',version='5')
    seq=add(root,'sequence',id='sequence-1')
    add(seq,'name',Path(path).stem)
    add(seq,'duration',sum(c.duration for c in cuts))
    rate(seq,used[0].fps)
    tc=add(seq,'timecode'); rate(tc,used[0].fps)
    add(tc,'string','00:00:00:00'); add(tc,'frame',0); add(tc,'displayformat','NDF')
    med=add(seq,'media'); video=add(med,'video')
    video_format(add(add(video,'format'),'samplecharacteristics'),used[0])
    vt=add(video,'track')
    audio=add(med,'audio')
    max_channels=max(m.channels for m in used)
    add(audio,'numOutputChannels',max_channels)
    af=add(add(audio,'format'),'samplecharacteristics')
    add(af,'depth',16); add(af,'samplerate',48000)
    ats=[add(audio,'track') for _ in range(max_channels)]
    file_ids={m.id:f'file-{i+1}' for i,m in enumerate({m.id:m for m in used}.values())}
    seen=set(); position=0
    audio_counts=[0]*max_channels
    for i,c in enumerate(cuts,1):
        m=media[c.media_id]
        ids=[f'v-{i}']+[f'a-{i}-{ch+1}' for ch in range(m.channels)]
        for ch in range(m.channels):
            audio_counts[ch]+=1
        for kind,channel,parent,clip_id in [('video',0,vt,ids[0])]+[('audio',ch+1,ats[ch],ids[ch+1]) for ch in range(m.channels)]:
            ci=add(parent,'clipitem',id=clip_id)
            add(ci,'name',f'{Path(m.path).name} | script {c.line_index+1}')
            add(ci,'enabled','TRUE'); add(ci,'duration',math.floor(m.duration*float(m.rate)+1e-6))
            rate(ci,m.fps)
            for tag,value in [('start',position),('end',position+c.duration),('in',c.start_frame),('out',c.end_frame)]:
                add(ci,tag,value)
            f=add(ci,'file',id=file_ids[m.id])
            if m.id not in seen:
                seen.add(m.id)
                add(f,'name',Path(m.path).name); add(f,'pathurl',Path(m.path).resolve().as_uri())
                rate(f,m.fps); add(f,'duration',math.floor(m.duration*float(m.rate)+1e-6))
                ft=add(f,'timecode'); rate(ft,m.fps)
                add(ft,'string','00:00:00:00'); add(ft,'frame',0); add(ft,'displayformat','NDF')
                fm=add(f,'media'); fv=add(fm,'video')
                video_format(add(fv,'samplecharacteristics'),m)
                fa=add(fm,'audio'); asc=add(fa,'samplecharacteristics')
                add(asc,'depth',16); add(asc,'samplerate',m.sample_rate)
                add(fa,'channelcount',m.channels)
            if kind=='audio':
                source=add(ci,'sourcetrack'); add(source,'mediatype','audio'); add(source,'trackindex',channel)
            for li,lid in enumerate(ids):
                link=add(ci,'link'); add(link,'linkclipref',lid)
                add(link,'mediatype','video' if li==0 else 'audio')
                add(link,'trackindex',1 if li==0 else li)
                add(link,'clipindex',i if li==0 else audio_counts[li-1])
                if li:
                    add(link,'groupindex',1)
        position+=c.duration
    ET.indent(root,space='  ')
    data=ET.tostring(root,encoding='utf-8',xml_declaration=True)
    Path(path).write_bytes(data.replace(b'?>',b'?>\n<!DOCTYPE xmeml>',1))
