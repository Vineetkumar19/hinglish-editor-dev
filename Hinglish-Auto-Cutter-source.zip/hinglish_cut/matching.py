"""Bounded global choice of ordered script matches, across unordered source takes."""
from .model import Selection
from .text import tokens, similarity


def candidates(script, transcript, settings):
    target=tokens(script,settings.aliases)
    observed=[]
    indices=[]
    for i,w in enumerate(transcript.words):
        ts=tokens(w.text,settings.aliases)
        observed.extend(ts)
        indices.extend([i]*len(ts))
    if not target or not observed:
        return []
    # Semi-global edit distance: all script words, a free source prefix/suffix.
    n=len(observed)
    prev=[0.0]*(n+1)
    origins=list(range(n+1))
    for i,a in enumerate(target,1):
        curr=[float(i)]+[0.0]*n
        starts=[0]*(n+1)
        for j,b in enumerate(observed,1):
            opts=((prev[j-1]+1-similarity(a,b),origins[j-1]),
                  (prev[j]+1,origins[j]),(curr[j-1]+1,starts[j-1]))
            curr[j],starts[j]=min(opts,key=lambda v:v[0])
        prev,origins=curr,starts
    found=[]
    for end in range(1,n+1):
        start=origins[end]
        score=1-prev[end]/max(len(target),end-start,1)
        if start>=end or score<settings.match_threshold:
            continue
        first,last=indices[start],indices[end-1]+1
        # Long gaps can indicate abandoned takes. Penalize excessive duration.
        duration=transcript.words[last-1].end-transcript.words[first].start
        score-=max(0,duration-max(12,len(target)*1.8))*.005
        found.append((score,first,last))
    # Nearby alternate endpoints of the same utterance are one candidate.
    distinct=[]
    for c in sorted(found,reverse=True):
        if any(max(c[1],d[1])<min(c[2],d[2]) for d in distinct):
            continue
        distinct.append(c)
        if len(distinct)>=settings.candidates_per_line:
            break
    return distinct


def arrange(lines, transcripts, settings):
    per_line=[]
    for i,line in enumerate(lines):
        pool=[]
        for t in transcripts:
            for score,start,end in candidates(line,t,settings):
                pool.append(Selection(i,line,t.media.id,start,end,score))
        pool.sort(key=lambda c:(-c.score,c.media_id,c.first_word))
        pool=pool[:settings.candidates_per_line]
        for c in pool:
            others=[x for x in pool if x is not c]
            c.ambiguous=any(abs(c.score-x.score)<=settings.ambiguity_margin for x in others)
            c.alternatives=[{'media_id':x.media_id,'first_word':x.first_word,'last_word':x.last_word,'score':round(x.score,4)} for x in others[:3]]
        per_line.append(pool)
    beam=[(0.0,[],{})]
    for i,pool in enumerate(per_line):
        expanded=[]
        for score,chosen,used in beam:
            expanded.append((score-.75,chosen+[Selection(i,lines[i],None)],used))
            for c in pool:
                if any(max(c.first_word,a)<min(c.last_word,b) for a,b in used.get(c.media_id,[])):
                    continue
                next_used={k:list(v) for k,v in used.items()}
                next_used.setdefault(c.media_id,[]).append((c.first_word,c.last_word))
                expanded.append((score+c.score,chosen+[c],next_used))
        beam=sorted(expanded,key=lambda x:x[0],reverse=True)[:settings.beam_width]
    return beam[0][1] if beam else []
