import re
import unicodedata
from difflib import SequenceMatcher
from functools import lru_cache


def tokens(text, aliases=None):
    text = unicodedata.normalize('NFKC',text).casefold()
    # Keep decimal numbers and negations. Do not strip vowels or collapse words.
    result = re.findall(r'\d+(?:[.,]\d+)*|[^\W\d_]+',text,re.UNICODE)
    aliases=aliases or {}
    return [aliases.get(t,t) for t in result]


def split_script(text):
    # Newlines are deliberate edit units; also recognize sentence punctuation.
    return [s.strip() for s in re.split(r'\n+|(?<=[!?।])\s+|(?<=\.)\s+',text) if tokens(s)]


@lru_cache(maxsize=100000)
def similarity(a,b):
    if a==b:
        return 1.0
    # Numbers must match exactly; small spelling differences are allowed in words.
    if any(c.isdigit() for c in a+b):
        return 0.0
    ratio = SequenceMatcher(None,a,b,autojunk=False).ratio()
    return ratio if ratio>=.72 else 0.0
