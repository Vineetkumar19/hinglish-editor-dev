import tempfile
import unittest
import wave
from pathlib import Path
from hinglish_cut.media import probe, extract_audio, assemble_audio
from hinglish_cut.demo import create_demo_media
from hinglish_cut.model import Cut


class MediaTests(unittest.TestCase):
    def test_real_media_audio_and_timeline_duration(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'raw & test.mp4'
            create_demo_media(p,seconds=3,frequency=440)
            m=probe(p)
            self.assertEqual(m.fps,'25')
            self.assertEqual(m.channels,2)
            wav=Path(d)/'source.wav'
            extract_audio(m,wav)
            out=Path(d)/'cut.wav'
            assemble_audio([Cut(m.id,5,15,0),Cut(m.id,30,50,0)],{m.id:m},{m.id:wav},out)
            with wave.open(str(out),'rb') as w:
                self.assertEqual(w.getnframes(),19200)
                self.assertEqual(w.getframerate(),16000)


if __name__=='__main__':
    unittest.main()
